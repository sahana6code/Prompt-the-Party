/* ============================================================
   Prompt the Party — shared site behavior
   1) Reveal-on-scroll for [data-reveal] elements, staggered by
      the --reveal-i custom property set per element.
   2) Floating side rail: builds one dot per [data-section],
      highlights the active one, and scrolls to it on click.
   Both respect prefers-reduced-motion.
   ============================================================ */

(function () {
  var prefersReduced = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;

  // ---------- 1) Reveal on scroll ----------
  var revealEls = document.querySelectorAll("[data-reveal]");
  if (revealEls.length) {
    if (prefersReduced || !("IntersectionObserver" in window)) {
      revealEls.forEach(function (el) { el.classList.add("is-visible"); });
    } else {
      var io = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              io.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.2, rootMargin: "0px 0px -10% 0px" }
      );
      revealEls.forEach(function (el, i) {
        el.style.setProperty("--reveal-i", i % 6);
        io.observe(el);
      });
    }
  }

  // ---------- 2) Floating side rail ----------
  var railHost = document.querySelector("[data-rail]");
  var sections = Array.prototype.slice.call(
    document.querySelectorAll("[data-section]")
  );
  if (railHost && sections.length) {
    var rail = document.createElement("div");
    rail.className = "rail";
    rail.setAttribute("aria-label", "Page sections");

    var dots = sections.map(function (section) {
      var dot = document.createElement("button");
      dot.className = "rail__dot";
      dot.type = "button";
      var label = section.getAttribute("data-section-label") || section.id;
      dot.innerHTML = '<span class="rail__label">' + label + "</span>";
      dot.setAttribute("aria-label", "Jump to " + label);
      dot.addEventListener("click", function () {
        section.scrollIntoView({
          behavior: prefersReduced ? "auto" : "smooth",
          block: "start",
        });
      });
      rail.appendChild(dot);
      return dot;
    });

    railHost.appendChild(rail);

    if ("IntersectionObserver" in window) {
      var railIo = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            var idx = sections.indexOf(entry.target);
            if (idx === -1) return;
            if (entry.isIntersecting) {
              dots.forEach(function (d) { d.classList.remove("is-active"); });
              dots[idx].classList.add("is-active");
            }
          });
        },
        { threshold: 0.5 }
      );
      sections.forEach(function (s) { railIo.observe(s); });
    }
  }
})();
