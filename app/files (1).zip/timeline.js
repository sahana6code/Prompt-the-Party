/* ============================================================
   Prompt the Party — timeline page
   Reads the order handed off from chat.html + secdp.html and
   renders it as five stages. Each stage's dropdown opens
   automatically the first time it scrolls into view, and can
   also be toggled by clicking its header. Stages 2 and 3 run a
   small staged checklist animation the first time they open —
   all mocked client-side; swap in real progress events from the
   LangGraph backend when it's wired up (see agent-brain-
   integration-contract.md for the `state.next_action` shape).
   ============================================================ */

(function () {
  var order = null;
  try { order = JSON.parse(sessionStorage.getItem("ptp:order")); } catch (e) { order = null; }

  var emptyState = document.getElementById("empty-state");
  var content = document.getElementById("timeline-content");

  if (!order || !order.brief) {
    emptyState.hidden = false;
    return;
  }
  content.hidden = false;

  var brief = order.brief;
  var logistics = order.logistics || {};

  var CATERERS = [
    { name: "Spice Trail Catering", cuisine: "Indian", price: 18, rating: "4.8", note: "Halal-certified kitchen, handles weddings weekly." },
    { name: "Wok & Roll", cuisine: "Chinese", price: 15, rating: "4.6", note: "Fast turnaround, strong for corporate lunches." },
    { name: "Nonna's Table", cuisine: "Italian", price: 22, rating: "4.9", note: "Family-run, plated service available." },
    { name: "Green Leaf Kitchen", cuisine: "Western", price: 16, rating: "4.5", note: "Full vegetarian and vegan menus by default." },
    { name: "Rempah & Co", cuisine: "Malay", price: 14, rating: "4.7", note: "Halal, specialises in buffet-style events." },
    { name: "Fusion Ninety", cuisine: "Fusion", price: 20, rating: "4.6", note: "Chef-curated tasting menus for smaller groups." },
    { name: "Seoul Kitchen", cuisine: "Korean", price: 19, rating: "4.7", note: "Grill stations on-site, popular for milestone parties." },
    { name: "Bangkok Basil", cuisine: "Thai", price: 17, rating: "4.5", note: "Spice levels adjusted per table on request." },
  ];

  var wantedCuisines = (brief.cuisine || []).map(function (c) { return c.toLowerCase(); });
  var matches = CATERERS.filter(function (c) { return wantedCuisines.indexOf(c.cuisine.toLowerCase()) !== -1; });
  var pool = matches.concat(CATERERS.filter(function (c) { return matches.indexOf(c) === -1; }));
  var top3 = pool.slice(0, 3);

  function venueLabel(value) {
    return { "home-party": "Home party", "restaurant": "Restaurant dine-in", "offsite-catering": "Off-site catering" }[value] || value || "\u2014";
  }
  function formatDate(iso) {
    if (!iso) return "\u2014";
    var d = new Date(iso + "T00:00:00");
    return d.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" });
  }

  // ---------- stage 1: requirements recap ----------

  function renderRequirements(el) {
    var dietaryText = brief.dietary && brief.dietary.length ? brief.dietary.join(", ") : "None";
    var dietaryCountText = brief.dietary && brief.dietary.length
      ? (brief.dietaryCount != null ? brief.dietaryCount + " of " + brief.pax + " guests" : "\u2014")
      : "N/A";

    var rows = [
      ["Guests", brief.pax != null ? brief.pax : "\u2014"],
      ["Cuisine", brief.cuisine && brief.cuisine.length ? brief.cuisine.join(", ") : "\u2014"],
      ["Dietary", dietaryText],
      ["Dietary headcount", dietaryCountText],
      ["Budget", brief.budget != null ? "$" + brief.budget.toLocaleString() : "\u2014"],
      ["Date", formatDate(logistics.date)],
      ["Time", logistics.start ? logistics.start + " \u2013 " + logistics.end : "\u2014"],
      ["Venue", venueLabel(logistics.venue)],
    ];

    var dl = document.createElement("dl");
    dl.className = "recap";
    rows.forEach(function (pair) {
      var row = document.createElement("div");
      var dt = document.createElement("dt");
      dt.textContent = pair[0];
      var dd = document.createElement("dd");
      dd.textContent = pair[1];
      row.appendChild(dt);
      row.appendChild(dd);
      dl.appendChild(row);
    });
    el.appendChild(dl);
  }

  // ---------- stages 2 & 3: staged checklists ----------

  function buildChecklist(el, items, summary) {
    var ul = document.createElement("ul");
    ul.className = "checklist";
    items.forEach(function (text) {
      var li = document.createElement("li");
      var tick = document.createElement("span");
      tick.className = "tick";
      var label = document.createElement("span");
      label.textContent = text;
      li.appendChild(tick);
      li.appendChild(label);
      ul.appendChild(li);
    });
    var summaryEl = document.createElement("p");
    summaryEl.className = "checklist__summary";
    summaryEl.textContent = summary;
    summaryEl.style.opacity = "0";
    summaryEl.style.transition = "opacity 0.4s ease-out";

    el.appendChild(ul);
    el.appendChild(summaryEl);

    return function play() {
      var lis = ul.querySelectorAll("li");
      lis.forEach(function (li, i) {
        setTimeout(function () { li.classList.add("is-shown"); }, i * 380);
      });
      setTimeout(function () { summaryEl.style.opacity = "1"; }, lis.length * 380 + 200);
    };
  }

  function renderSearching(el) {
    var cuisineText = brief.cuisine && brief.cuisine.length ? brief.cuisine.join(" / ") : "any cuisine";
    var items = [
      "Checking availability for " + formatDate(logistics.date),
      "Filtering by " + cuisineText,
      "Matching within a $" + (brief.budget || 0).toLocaleString() + " budget",
      brief.dietary && brief.dietary.length ? "Confirming " + brief.dietary.join(", ") + " options" : "No dietary restrictions to filter for",
    ];
    return buildChecklist(el, items, top3.length + " caterers matched your brief");
  }

  function renderContacting(el) {
    var items = pool.slice(0, Math.min(5, pool.length)).map(function (c) { return "Message sent to " + c.name; });
    return buildChecklist(el, items, items.length + " caterers contacted \u2014 waiting on replies");
  }

  // ---------- stage 4: shortlist ----------

  function renderShortlist(el) {
    var intro = document.createElement("p");
    intro.textContent = "Here's your shortlist" + (brief.pax ? " for " + brief.pax + " guests" : "") + ":";
    intro.style.marginBottom = "14px";
    el.appendChild(intro);

    top3.forEach(function (c) {
      var card = document.createElement("div");
      card.className = "result-card";

      var left = document.createElement("div");
      var name = document.createElement("div");
      name.className = "result-card__name";
      name.textContent = c.name;
      var meta = document.createElement("div");
      meta.className = "result-card__meta";
      meta.textContent = c.cuisine + " \u2014 " + c.rating + "/5";
      var note = document.createElement("div");
      note.className = "result-card__note";
      note.textContent = c.note;
      left.appendChild(name);
      left.appendChild(meta);
      left.appendChild(note);

      var price = document.createElement("div");
      price.className = "result-card__price";
      price.textContent = brief.pax ? "$" + (c.price * brief.pax).toLocaleString() + " total" : "$" + c.price + "/head";

      card.appendChild(left);
      card.appendChild(price);
      el.appendChild(card);
    });
  }

  // ---------- stage 5: ready to book ----------

  function renderBook(el) {
    var top = top3[0];
    if (top) {
      var pick = document.createElement("div");
      pick.className = "book-pick";
      var badge = document.createElement("div");
      badge.className = "book-pick__badge";
      badge.textContent = "Recommended";
      var name = document.createElement("div");
      name.className = "book-pick__name";
      name.textContent = top.name;
      var meta = document.createElement("div");
      meta.className = "book-pick__meta";
      meta.textContent = top.cuisine + " \u2014 " + top.rating + "/5 \u2014 " +
        (brief.pax ? "$" + (top.price * brief.pax).toLocaleString() + " total" : "$" + top.price + "/head");
      pick.appendChild(badge);
      pick.appendChild(name);
      pick.appendChild(meta);
      el.appendChild(pick);
    }

    var actions = document.createElement("div");
    actions.className = "book-actions";

    var messageBtn = document.createElement("button");
    messageBtn.type = "button";
    messageBtn.className = "btn-ticket";
    messageBtn.textContent = top ? "Message " + top.name : "Message caterer";
    messageBtn.addEventListener("click", function () {
      messageBtn.textContent = "Message sent";
      messageBtn.disabled = true;
    });

    var restartLink = document.createElement("a");
    restartLink.href = "chat.html";
    restartLink.className = "btn-ticket btn-ticket--outline";
    restartLink.textContent = "Start a new ticket";
    restartLink.addEventListener("click", function () {
      sessionStorage.removeItem("ptp:brief");
      sessionStorage.removeItem("ptp:order");
    });

    actions.appendChild(messageBtn);
    actions.appendChild(restartLink);
    el.appendChild(actions);
  }

  // ---------- wire it all up ----------

  var renderers = {
    requirements: renderRequirements,
    searching: renderSearching,
    contacting: renderContacting,
    shortlist: renderShortlist,
    book: renderBook,
  };

  var playFns = {};
  document.querySelectorAll("[data-content]").forEach(function (el) {
    var key = el.getAttribute("data-content");
    var result = renderers[key](el);
    if (typeof result === "function") playFns[key] = result;
  });

  var stages = Array.prototype.slice.call(document.querySelectorAll(".timeline__stage"));

  function openStage(stage) {
    if (stage.classList.contains("is-open")) return;
    stage.classList.add("is-open");
    var toggle = stage.querySelector(".timeline__toggle");
    toggle.setAttribute("aria-expanded", "true");
    var key = stage.getAttribute("data-stage");
    if (playFns[key]) playFns[key]();
  }

  stages.forEach(function (stage) {
    var toggle = stage.querySelector(".timeline__toggle");
    toggle.addEventListener("click", function () {
      var isOpen = stage.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(isOpen));
      if (isOpen) {
        var key = stage.getAttribute("data-stage");
        if (playFns[key]) playFns[key]();
      }
    });
  });

  var prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (prefersReduced || !("IntersectionObserver" in window)) {
    stages.forEach(openStage);
  } else {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            openStage(entry.target);
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.35, rootMargin: "0px 0px -15% 0px" }
    );
    stages.forEach(function (s) { io.observe(s); });
  }
})();
