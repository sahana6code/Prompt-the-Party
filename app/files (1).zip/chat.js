/* ============================================================
   Prompt the Party — chat page
   Self-contained front-end demo: extracts the 5 primary data
   points (pax, cuisine, dietary, dietary headcount, budget)
   with simple regex — the same fields user_req.py already
   works with — then hands the approved brief to the
   event-details page via sessionStorage. Swap `finalize()`'s
   handoff for a real call to the LangGraph backend once it's
   deployed; see the TODO below.
   ============================================================ */

(function () {
  var chatWindow = document.getElementById("chat-window");
  var form = document.getElementById("chat-form");
  var input = document.getElementById("user-input");
  var resetBtn = document.getElementById("reset-btn");
  var continueBtn = document.getElementById("continue-btn");
  var ticketStatus = document.getElementById("ticket-status");

  var CUISINES = [
    "indian", "chinese", "western", "japanese", "korean", "italian",
    "malay", "thai", "mexican", "fusion", "peranakan", "vietnamese",
  ];
  var DIETARY = [
    "halal", "vegetarian", "vegan", "gluten-free", "gluten free",
    "no pork", "no beef", "kosher", "nut allergy", "dairy-free",
  ];

  var state = { pax: null, cuisine: null, dietary: null, dietaryCount: null, budget: null };
  var awaiting = null; // which field the next message is answering
  var announcedComplete = false;

  function titleCase(s) {
    return s.replace(/\w\S*/g, function (t) {
      return t.charAt(0).toUpperCase() + t.slice(1).toLowerCase();
    });
  }

  // ---------- extraction helpers (mirrors user_req.py's fields) ----------

  function findPax(text) {
    var m = text.match(/(\d{1,4})\s*(?:pax|guests?|people|pers|attendees|heads)/i);
    if (m) return parseInt(m[1], 10);
    m = text.match(/for\s+(\d{1,4})\s/i);
    if (m) return parseInt(m[1], 10);
    return null;
  }

  function findBudget(text) {
    var m = text.match(/\$\s?([\d,]+)/);
    if (m) return parseInt(m[1].replace(/,/g, ""), 10);
    m = text.match(/budget[^\d]{0,12}([\d,]{2,7})/i);
    if (m) return parseInt(m[1].replace(/,/g, ""), 10);
    return null;
  }

  function findCuisine(text) {
    var lower = text.toLowerCase();
    var hits = CUISINES.filter(function (c) { return lower.indexOf(c) !== -1; });
    return hits.length ? hits.map(titleCase) : null;
  }

  function findDietary(text) {
    var lower = text.toLowerCase();
    if (/\b(no|none|nope|nil)\b/.test(lower) && lower.length < 40) return [];
    var hits = DIETARY.filter(function (d) { return lower.indexOf(d) !== -1; });
    return hits.length ? hits.map(titleCase) : null;
  }

  function extractAll(text) {
    if (state.pax == null) { var p = findPax(text); if (p != null) state.pax = p; }
    if (state.cuisine == null) { var c = findCuisine(text); if (c != null) state.cuisine = c; }
    if (state.dietary == null) { var d = findDietary(text); if (d != null) state.dietary = d; }
    if (state.budget == null) { var b = findBudget(text); if (b != null) state.budget = b; }
  }

  // Lenient fallback for whichever field we just explicitly asked about
  function captureAwaitingField(text) {
    if (!awaiting) return;
    var lower = text.toLowerCase().trim();
    if (awaiting === "pax" && state.pax == null) {
      var m = text.match(/\d{1,4}/);
      if (m) state.pax = parseInt(m[0], 10);
    } else if (awaiting === "cuisine" && state.cuisine == null) {
      state.cuisine = lower.split(/,|and/).map(function (s) { return titleCase(s.trim()); }).filter(Boolean);
    } else if (awaiting === "dietary" && state.dietary == null) {
      state.dietary = /\b(no|none|nope|nil)\b/.test(lower)
        ? []
        : lower.split(/,|and/).map(function (s) { return titleCase(s.trim()); }).filter(Boolean);
    } else if (awaiting === "dietaryCount" && state.dietaryCount == null) {
      if (/\ball\b|everyone|everybody/.test(lower) && state.pax) {
        state.dietaryCount = state.pax;
      } else {
        var m2 = text.match(/\d{1,4}/);
        if (m2) state.dietaryCount = parseInt(m2[0], 10);
      }
    } else if (awaiting === "budget" && state.budget == null) {
      var m3 = text.match(/[\d,]{2,7}/);
      if (m3) state.budget = parseInt(m3[0].replace(/,/g, ""), 10);
    }
  }

  // ---------- rendering ----------

  function appendMessage(text, who) {
    var el = document.createElement("div");
    el.className = "message " + who;
    el.textContent = text;
    chatWindow.appendChild(el);
    chatWindow.scrollTop = chatWindow.scrollHeight;
    return el;
  }

  function updateTicket() {
    setField("pax", state.pax == null ? null : state.pax + " guests");
    setField("cuisine", state.cuisine == null ? null : (state.cuisine.length ? state.cuisine.join(", ") : "Not specified"));
    setField("dietary", state.dietary == null ? null : (state.dietary.length ? state.dietary.join(", ") : "None"));

    var dietaryCountText;
    if (state.dietary == null) dietaryCountText = null;
    else if (state.dietary.length === 0) dietaryCountText = "N/A";
    else if (state.dietaryCount == null) dietaryCountText = "Pending";
    else dietaryCountText = state.dietaryCount + " of " + (state.pax || "\u2014") + " guests";
    setField("dietaryCount", dietaryCountText);

    setField("budget", state.budget == null ? null : "$" + state.budget.toLocaleString());

    var complete = isComplete();
    ticketStatus.textContent = complete ? "Ready" : "In progress";
    ticketStatus.classList.toggle("is-ready", complete);
    continueBtn.disabled = !complete;
  }

  function setField(key, value) {
    var field = document.querySelector('.ticket-field[data-field="' + key + '"]');
    var dd = field.querySelector("dd");
    var current = dd.textContent;
    if (value == null || value === current) return;
    dd.textContent = value;
    field.classList.remove("is-filled");
    void field.offsetWidth; // restart animation
    field.classList.add("is-filled");
  }

  function isComplete() {
    return (
      state.pax != null &&
      state.cuisine != null &&
      state.dietary != null &&
      (state.dietary.length === 0 || state.dietaryCount != null) &&
      state.budget != null
    );
  }

  // ---------- conversation flow ----------

  function askNext() {
    if (state.pax == null) { awaiting = "pax"; appendMessage("How many guests are you expecting?", "bot"); return; }
    if (state.cuisine == null) { awaiting = "cuisine"; appendMessage("What cuisine are you after \u2014 Indian, Western, fusion, something else?", "bot"); return; }
    if (state.dietary == null) { awaiting = "dietary"; appendMessage("Any dietary needs I should flag, like halal or vegetarian? Say \u201cno\u201d if not.", "bot"); return; }
    if (state.dietary.length > 0 && state.dietaryCount == null) {
      awaiting = "dietaryCount";
      appendMessage("Got it \u2014 how many of your guests need " + state.dietary.join(", ") + "?", "bot");
      return;
    }
    if (state.budget == null) { awaiting = "budget"; appendMessage("Last one \u2014 what's the budget you're working with?", "bot"); return; }
    awaiting = null;
    announceComplete();
  }

  function announceComplete() {
    if (announcedComplete) return;
    announcedComplete = true;
    appendMessage("That's everything I need. Take a look at your ticket on the right, and hit continue when it looks good.", "bot");
  }

  function handleSend(text) {
    if (!text.trim()) return;
    appendMessage(text, "user");
    extractAll(text);
    captureAwaitingField(text);
    updateTicket();
    if (isComplete()) {
      announceComplete();
    } else {
      askNext();
    }
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var text = input.value;
    input.value = "";
    handleSend(text);
  });

  continueBtn.addEventListener("click", function () {
    if (continueBtn.disabled) return;
    // TODO: once the LangGraph backend is deployed, POST this brief
    // (matching agent-brain-integration-contract.md's `brief` shape)
    // instead of, or alongside, storing it locally for the next page.
    sessionStorage.setItem("ptp:brief", JSON.stringify(state));
    window.location.href = "secdp.html";
  });

  resetBtn.addEventListener("click", function () {
    state = { pax: null, cuisine: null, dietary: null, dietaryCount: null, budget: null };
    awaiting = null;
    announcedComplete = false;
    chatWindow.innerHTML = "";
    appendMessage("Let's start fresh. Tell me about the event you're planning \u2014 guest count, cuisine, dietary needs, and budget.", "bot");
    updateTicket();
    input.focus();
  });

  updateTicket();
})();
