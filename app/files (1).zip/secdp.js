/* ============================================================
   Prompt the Party — event details page
   This page is only reachable once the chat has produced an
   approved brief (see chat.js). If someone lands here directly
   without one, send them back to start the conversation first.
   On submit, the brief + these logistics are merged and handed
   off to the timeline page via sessionStorage.
   ============================================================ */

(function () {
  var brief = null;
  try { brief = JSON.parse(sessionStorage.getItem("ptp:brief")); } catch (e) { brief = null; }
  if (!brief) {
    window.location.href = "chat.html";
    return;
  }

  var form = document.getElementById("event-form");
  var rail = document.getElementById("progress-rail");
  var dots = {};
  Array.prototype.forEach.call(rail.querySelectorAll(".rail__dot"), function (dot) {
    dots[dot.getAttribute("data-group")] = dot;
    dot.addEventListener("click", function () {
      var group = document.getElementById(dot.getAttribute("data-group") + "-group")
        || document.querySelector('[data-group="' + dot.getAttribute("data-group") + '"]');
      if (group) group.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  });

  function checkWhenGroup() {
    var date = document.getElementById("event-date");
    var start = document.getElementById("start-time");
    var end = document.getElementById("end-time");
    [date, start, end].forEach(function (el) {
      el.closest(".field-row").classList.toggle("is-complete", !!el.value);
    });
    var complete = date.value && start.value && end.value;
    dots.when.classList.toggle("is-active", !!complete);
    return complete;
  }

  function checkServiceGroup() {
    var checked = form.querySelector('input[name="service-type"]:checked');
    dots.service.classList.toggle("is-active", !!checked);
    return !!checked;
  }

  ["event-date", "start-time", "end-time"].forEach(function (id) {
    document.getElementById(id).addEventListener("input", checkWhenGroup);
  });
  Array.prototype.forEach.call(
    form.querySelectorAll('input[name="service-type"]'),
    function (el) { el.addEventListener("change", checkServiceGroup); }
  );

  function serviceLabel(value) {
    return { "home-party": "Home party", "restaurant": "Restaurant dine-in", "offsite-catering": "Off-site catering" }[value] || value;
  }

  function formatDate(iso) {
    if (!iso) return "\u2014";
    var d = new Date(iso + "T00:00:00");
    return d.toLocaleDateString(undefined, { weekday: "short", day: "2-digit", month: "short", year: "numeric" });
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (!form.checkValidity()) { form.reportValidity(); return; }

    var date = document.getElementById("event-date").value;
    var start = document.getElementById("start-time").value;
    var end = document.getElementById("end-time").value;
    var service = form.querySelector('input[name="service-type"]:checked').value;

    dots.confirm.classList.add("is-active");

    var order = {
      brief: brief,
      logistics: { date: date, start: start, end: end, venue: service },
    };
    sessionStorage.setItem("ptp:order", JSON.stringify(order));

    var details = document.getElementById("confirmation-details");
    details.innerHTML = "";
    [
      ["Date", formatDate(date)],
      ["Time", start + " \u2013 " + end],
      ["Venue", serviceLabel(service)],
    ].forEach(function (pair) {
      var row = document.createElement("div");
      var dt = document.createElement("dt");
      dt.textContent = pair[0];
      var dd = document.createElement("dd");
      dd.textContent = pair[1];
      row.appendChild(dt);
      row.appendChild(dd);
      details.appendChild(row);
    });

    form.hidden = true;
    var confirmation = document.getElementById("confirmation");
    confirmation.hidden = false;
    confirmation.scrollIntoView({ behavior: "smooth", block: "center" });

    setTimeout(function () {
      window.location.href = "timeline.html";
    }, 1300);
  });

  checkWhenGroup();
  checkServiceGroup();
})();
